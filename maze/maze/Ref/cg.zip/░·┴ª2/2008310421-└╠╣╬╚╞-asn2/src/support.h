#pragma once

// support functions defined in support.cpp
void setWorkingDirToBinDir( const char* argv0 );
bool checkShader( GLuint shaderID, const char* shaderName );
bool checkProgram( GLuint programID, const char* programName );
char* readShader( const char* filePath );
bool initExtensions();
