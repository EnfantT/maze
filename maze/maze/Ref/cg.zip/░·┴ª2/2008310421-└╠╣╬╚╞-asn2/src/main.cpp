#include "cgmath-min.h"		// slee's simple math library
#include "GL/glew.h"		// glew.sourceforge.net
#include "GL/freeglut.h"	// freeglut.sourceforge.net
#include "support.h"		// declaration for support functions

#pragma comment( lib, "OpenGL32.lib" )	// inline linking for OpenGL
#pragma comment( lib, "glew32.lib" )	// inline linking for glew
#pragma comment( lib, "freeglut.lib" )	// inline linking for freeGLUT

//*******************************************************************
// global variables
GLuint	program=0;					// ID holder for GPU program
GLuint	vertexShader=0;				// ID holder for vertex shader
GLuint	fragmentShader=0;			// ID holder for fragment shader
GLuint	vertexPositionBuffer=0;		// ID holder for vertex position buffer
GLuint	vertexColorBuffer=0;		// ID holder for vertex color buffer

// user flags
bool	bMouseLButtonDown=false;
bool	bUseAnotherColor=false;
vec4	anotherColor = vec4( 1.0f, 0.0f, 0.0f, 1.0f );
vec4	vertexColor = vec4(1.0f, 1.0f, 0.0f, 1.0f);
GLfloat aspectRatio;

//*******************************************************************
void updateUniforms()
{
	// update uniform variables
	GLuint loc0 = glGetUniformLocation( program, "bUseAnotherColor" );
	glUniform1i( loc0, bUseAnotherColor );

	GLuint loc1 = glGetUniformLocation( program, "anotherColor" );
	glUniform4f( loc1, anotherColor.x, anotherColor.y, anotherColor.z, anotherColor.w );

	GLuint loc2 = glGetUniformLocation(program, "aspectRatio");
	glUniform1f(loc2, aspectRatio);

	GLuint loc3 = glGetUniformLocation(program, "vertexColor");
	glUniform4f(loc3, vertexColor.x, vertexColor.y, vertexColor.z, vertexColor.w);
}

void render()
{
	// clear screen (with background color) and clear depth buffer
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	
	// notify to GL that we like to use our program now
	glUseProgram( program );

	// bind vertex position buffer
	GLuint vertexPositionLoc = glGetAttribLocation( program, "position" );
	glEnableVertexAttribArray( vertexPositionLoc );
	glBindBuffer( GL_ARRAY_BUFFER, vertexPositionBuffer );
	glVertexAttribPointer( vertexPositionLoc, 2, GL_FLOAT, GL_FALSE, 0, 0 );

	glDrawArrays( GL_TRIANGLES, 0, 72*3 );

	// now swap backbuffer with front buffer, and display it
	glutSwapBuffers();
}

void display()
{
	updateUniforms();
	render();
}

void reshape( int width, int height )
{
	// set current viewport in pixels
	// viewport: the window area that are affected by rendering
	// (win_x, win_y, win_width, win_height)
	glViewport( 0, 0, width, height );

	aspectRatio = width / float(height);
	// post signal to call display
	// this causes GL to call display() soon
	// but, we do not know exactly when dipslay() is called
	glutPostRedisplay();				
}

void mouse( int button, int state, int x, int y )
{
	if(button==GLUT_LEFT_BUTTON)
	{
		bMouseLButtonDown = (state==GLUT_DOWN);
		if(bMouseLButtonDown) printf( "Left mouse button pressed at (%d, %d)\n", x, y );
	}
}

void motion( int x, int y )
{
}

void idle()
{
	glutPostRedisplay();	// signal to call display soon
}

void keyboard( unsigned char key, int x, int y )
{
	if(key==27||key=='q'||key=='Q')		// ESCAPE
	{
		exit(0);
	}
	else if(key==' ')
	{
		bUseAnotherColor = !bUseAnotherColor;
		printf( "bUseAnotherColor = %d\n", bUseAnotherColor );
	}
}

bool initShaders( const char* vertShaderPath, const char* fragShaderPath )
{
	// create a program before linking shaders
	program = glCreateProgram();
	glUseProgram( program );

	// compile shader sources
	vertexShader = glCreateShader( GL_VERTEX_SHADER );
	const char* vertexShaderSource = readShader( vertShaderPath ); if(vertexShaderSource==NULL) return false;
	GLint vertexShaderLength = strlen(vertexShaderSource);
	glShaderSource( vertexShader, 1, &vertexShaderSource, &vertexShaderLength );
	glCompileShader( vertexShader );
	if(!checkShader( vertexShader, "vertexShader" )){ printf( "Unable to compile vertex shader\n" ); return false; }
	
	fragmentShader = glCreateShader( GL_FRAGMENT_SHADER );
	const char* fragmentShaderSource = readShader( fragShaderPath ); if(fragmentShaderSource==NULL) return false;
	GLint fragmentShaderLength = strlen(fragmentShaderSource);
	glShaderSource( fragmentShader, 1, &fragmentShaderSource, &fragmentShaderLength );
	glCompileShader( fragmentShader );
	if(!checkShader( fragmentShader, "fragmentShader" )){ printf( "Unable to compile fragment shader\n" ); return false; }
	
	// attach vertex/fragments shaders and link program
	glAttachShader( program, vertexShader );
	glAttachShader( program, fragmentShader );
	glLinkProgram( program );
	if(!checkProgram( program, "program" )){ printf( "Unable to link program\n" ); return false; }

	// deallocate string
	free((void*)vertexShaderSource);
	free((void*)fragmentShaderSource);

	return true;
}

bool userInit()
{
	// init GL states
	glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );		// clear color for glClear()
	glEnable( GL_CULL_FACE );					// turn on backface culling
	glEnable( GL_DEPTH_TEST );					// turn on depth tests
	float theta = 0;
	// create a vertex array for a triangle position
	// default viewing volume: [-1~1, -1~1, -1~1]

	vec2 triVertices[72*3];
	for (int i = 0; i < 72*3; i++){
		if (i%3==0)
			triVertices[i] = vec2(0, 0);
		else if (i % 3 == 1){
			triVertices[i] = vec2(0.5f * cos(theta), 0.5f * sin(theta));
			theta += PI / 36;
		}
		else if (i%3==2)
			triVertices[i] = vec2(0.5f * cos(theta), 0.5f * sin(theta));
	}
	glGenBuffers(1, &vertexPositionBuffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertexPositionBuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(triVertices), triVertices, GL_STATIC_DRAW);

	return true;
}

int main( int argc, char* argv[] )
{
	setWorkingDirToBinDir( argv[0] );					// change working directory to the current' binary's directory

	// GLUT initialization
	glutInit( &argc, argv );							// default initialization for GLUT
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA );		// double buffering with RGBA frame buffer

	int screenWidth = glutGet(GLUT_SCREEN_WIDTH);
	int screenHeight = glutGet(GLUT_SCREEN_HEIGHT);
	int windowWidth = 720;
	int windowHeight = 480;

	glutInitWindowSize(windowWidth, windowHeight);
	glutInitWindowPosition((screenWidth - windowWidth) / 2, (screenHeight - windowHeight) / 2);
	glutCreateWindow( "Drawing a Circle" );

	// Register callbacks
	glutDisplayFunc( display );		// callback when window is drawing
	glutReshapeFunc( reshape );		// callback when window is resized
	glutKeyboardFunc( keyboard );	// callback for keyboard input
	glutMouseFunc( mouse );			// callback for mouse click input
	glutMotionFunc( motion );		// callback for mouse movement input
	glutIdleFunc( idle );			// callback for idle time

	// init and check GLEW, version, extensions
	if(!initExtensions()){ printf( "Failed to init extensions.\n" ); return 0; }
	
	// create and compile shaders/program
	if(!initShaders("shaders/hello.vert","shaders/hello.frag")){ printf( "Failed to init program and shaders\n" ); return 0; }

	// user initialization
	if(!userInit()){ printf( "Failed to userInit()\n" ); return 0; }

	// Start rendering loop
	glutMainLoop();					// enters into rendering loop
	return 0;
}
