#include "cgmath.h"		// slee's simple math library
#include "GL/glew.h"		// glew.sourceforge.net
#include "GL/freeglut.h"	// freeglut.sourceforge.net
#include "support.h"		// declaration for support functions
#include "trackball.h"
#include <time.h>

#pragma comment( lib, "OpenGL32.lib" )	// inline linking for OpenGL
#pragma comment( lib, "glew32.lib" )	// inline linking for glew
#pragma comment( lib, "freeglut.lib" )	// inline linking for freeGLUT

// forward declaration of image loader function available at stb_image.c
extern "C" unsigned char*	stbi_load( const char* filename, int* x, int* y, int* comp, int req_comp );
extern "C" void				stbi_image_free( void* retval_from_stbi_load );

//*******************************************************************
// custom struct
struct Planet {
	vec3 center;
	float radius;
	float rot;		//rotation
	float rev;		//revolution
	Planet *parent = (Planet*)malloc(sizeof(Planet));
};

// user constant

const int NUM_moon = 10;

// global variables
GLuint	program=0;					// ID holder for GPU program
GLuint	vertexShader=0;				// ID holder for vertex shader
GLuint	fragmentShader=0;			// ID holder for fragment shader
GLuint	vertexPositionBuffer=0;		// ID holder for vertex position buffer
GLuint	indexBuffer=0;
GLuint	planetTexture[19]= { 0, };
int     windowWidth, windowHeight;
bool	isSun = false;

// user flags
bool	bMouseLButtonDown=false;
bool	bMouseRButtonDown=false;

//*******************************************************************
// global data
Camera		camera;
Light		light;
Material	material;
Trackball	trackball(camera.viewMatrix, 1.0f);
Trackball	zoom(camera.viewMatrix, 1.0f);
Trackball	pan(camera.viewMatrix, 1.0f);

int			FRAME = 0;

Planet	planet[9];
Planet	moon[10];

//*******************************************************************
void updateUniforms()
{
	// configure projection matrix
	camera.fovy = PI / 3.0f;
	//camera.aspectRatio; // udpate in reshape()
	camera.dNear = 100.0f;
	camera.dFar = 10000.0f;
	camera.projectionMatrix = mat4::perspective(camera.fovy, camera.aspectRatio, camera.dNear, camera.dFar);

	// setup uniform matrix
	glUniformMatrix4fv( glGetUniformLocation( program, "viewMatrix" ), 1, GL_TRUE, camera.viewMatrix );
	glUniformMatrix4fv( glGetUniformLocation( program, "projectionMatrix" ), 1, GL_TRUE, camera.projectionMatrix );

	// setup light properties
	glUniform4fv( glGetUniformLocation( program, "lightPosition" ), 1, light.position );
	glUniform4fv( glGetUniformLocation( program, "Ia" ), 1, light.ambient );
	glUniform4fv( glGetUniformLocation( program, "Id" ), 1, light.diffuse );
	glUniform4fv( glGetUniformLocation( program, "Is" ), 1, light.specular );

    // setup material properties
	glUniform4fv( glGetUniformLocation( program, "Ka" ), 1, material.ambient );
	glUniform4fv( glGetUniformLocation( program, "Kd" ), 1, material.diffuse );
	glUniform4fv( glGetUniformLocation( program, "Ks" ), 1, material.specular );
	glUniform1f( glGetUniformLocation( program, "shininess" ), material.shininess );

}

void render()
{
	// clear screen (with background color) and clear depth buffer
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	
	// notify to GL that we like to use our program now
	glUseProgram( program );

	// bind vertex position buffer
	glBindBuffer( GL_ARRAY_BUFFER, vertexPositionBuffer );

	// bind vertex position buffer
	GLuint vertexPositionLoc = glGetAttribLocation( program, "position" );
	glEnableVertexAttribArray( vertexPositionLoc );
	glVertexAttribPointer(vertexPositionLoc, sizeof(vertex().pos)/sizeof(GLfloat), GL_FLOAT, GL_FALSE, sizeof(vertex), 0 );

	// bind vertex normal buffer
	GLuint vertexNormalLoc = glGetAttribLocation( program, "normal" );
	glEnableVertexAttribArray( vertexNormalLoc );
	glVertexAttribPointer(vertexNormalLoc, sizeof(vertex().norm)/sizeof(GLfloat), GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)(sizeof(vertex().pos)) );

	// bind vertex texture buffer
	GLuint vertexTexLoc = glGetAttribLocation( program, "texcoord" );
	glEnableVertexAttribArray( vertexTexLoc );
	glVertexAttribPointer(vertexTexLoc, sizeof(vertex().tex)/sizeof(GLfloat), GL_FLOAT, GL_FALSE, sizeof(vertex), (GLvoid*)(sizeof(vertex().pos)+sizeof(vertex().norm)) );

	// render vertices: trigger shader programs to process vertex data
	glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, indexBuffer );
	
	// render the same object for n-times.
	for (int i = 0; i < 9; i++){
		// configure parameters for model matrix
		if (i == 0)
			isSun = true;
		else
			isSun = false;

		glUniform1i(glGetUniformLocation(program, "isSun"), isSun);
		clock_t temp = clock();
		float rot_theta = float(temp)*0.001f*planet[i].rot;
		float rev_theta = float(temp)*0.002f*planet[i].rev;
		//float move = planet[i].pos*5.0f;

		// calculate the model matrix for the desired position.
		mat4 modelMatrix = mat4::identity();
		modelMatrix = mat4::translate(vec3(0,0,0)) * modelMatrix;
		modelMatrix = mat4::rotateX(-PI / 2) * modelMatrix;
		modelMatrix = mat4::rotateY(rot_theta) * modelMatrix;
		modelMatrix = mat4::scale( planet[i].radius, planet[i].radius, planet[i].radius ) * modelMatrix;
		modelMatrix = mat4::translate(planet[i].center) * modelMatrix;
		modelMatrix = mat4::rotateY(rev_theta) * modelMatrix;

		glUniformMatrix4fv( glGetUniformLocation( program, "modelMatrix" ), 1, GL_TRUE, modelMatrix );
			
		glBindTexture( GL_TEXTURE_2D, planetTexture[i] );
		glUniform1i( glGetUniformLocation( program, "TEX" ), 0 );	 // GL_TEXTURE0
		
		glDrawElements( GL_TRIANGLES, 36*36*6, GL_UNSIGNED_INT, NULL );
	}		
	
	// render the same object for n-times.
	for (int i = 0; i < 10; i++){
		// configure parameters for model matrix
		isSun = false;
		glUniform1i(glGetUniformLocation(program, "isSun"), isSun);
		
		clock_t temp = clock();
		float rot_theta = float(temp)*0.001f*moon[i].rot;
		float rev_theta = float(temp)*0.001f*moon[i].rev;
		float p_rev_theta = float(temp)*0.002f*moon[i].parent->rev;

		// calculate the model matrix for the desired position.
		mat4 modelMatrix = mat4::identity();
		modelMatrix = mat4::translate(vec3(0, 0, 0)) * modelMatrix;
		modelMatrix = mat4::rotateX(-PI / 2) * modelMatrix;
		modelMatrix = mat4::rotateY(rot_theta) * modelMatrix;
		modelMatrix = mat4::scale(moon[i].radius, moon[i].radius, moon[i].radius) * modelMatrix;
		modelMatrix = mat4::translate(moon[i].center) * modelMatrix;
		modelMatrix = mat4::rotateY(rev_theta) * modelMatrix;
		modelMatrix = mat4::translate(moon[i].parent->center) * modelMatrix;
		modelMatrix = mat4::rotateY(p_rev_theta) * modelMatrix;

		glUniformMatrix4fv(glGetUniformLocation(program, "modelMatrix"), 1, GL_TRUE, modelMatrix);

		glBindTexture(GL_TEXTURE_2D, planetTexture[i+9]);
		glUniform1i(glGetUniformLocation(program, "TEX"), 0);	 // GL_TEXTURE0

		glDrawElements(GL_TRIANGLES, 36 * 36 * 6, GL_UNSIGNED_INT, NULL);
	}	// now swap backbuffer with front buffer, and display it
	glutSwapBuffers();
}

void display()
{
	updateUniforms();
	render();
}

void reshape( int width, int height )
{
	// set current viewport in pixels
	// viewport: the window area that are affected by rendering
	// (win_x, win_y, win_width, win_height)
	glViewport( 0, 0, windowWidth = width, windowHeight = height );

	camera.aspectRatio = float(width)/float(height);

	// post signal to call display
	// this causes GL to call display() soon
	// but, we do not know exactly when dipslay() is called
	glutPostRedisplay();
}

void mouse(int button, int state, int x, int y)
{
	if (button == GLUT_LEFT_BUTTON)
	{
		if (state == GLUT_DOWN) {
			if (glutGetModifiers() == GLUT_ACTIVE_SHIFT)
				zoom.begin(x / float(windowWidth - 1), y / float(windowHeight - 1), camera.viewMatrix);
			else if (glutGetModifiers() == GLUT_ACTIVE_CTRL)
				pan.begin(x / float(windowWidth - 1), y / float(windowHeight - 1), camera.viewMatrix);
			else
				trackball.begin(x / float(windowWidth - 1), y / float(windowHeight - 1), camera.viewMatrix);
		}
		else if (state == GLUT_UP) {
			trackball.end();
			zoom.end();
			pan.end();			
		}
	}
	if (button == GLUT_RIGHT_BUTTON) {
		if (state == GLUT_DOWN)	zoom.begin(x / float(windowWidth - 1), y / float(windowHeight - 1), camera.viewMatrix);
		else if (state == GLUT_UP) zoom.end();
	}
	if (button == GLUT_MIDDLE_BUTTON) {
		if (state == GLUT_DOWN)	pan.begin(x / float(windowWidth - 1), y / float(windowHeight - 1), camera.viewMatrix);
		else if (state == GLUT_UP) pan.end();
	}
}

void motion(int x, int y)
{
	// while moving mouse, update camera matrix
	trackball.track(x / float(windowWidth - 1), y / float(windowHeight - 1));
	zoom.zoom(x / float(windowWidth - 1), y / float(windowHeight - 1));
	pan.pan(x / float(windowWidth - 1), y / float(windowHeight - 1));
}

void idle()
{
	glutPostRedisplay();	// signal to call display soon
}

void keyboard( unsigned char key, int x, int y )
{
	if (key == 27 || key == 'q' || key == 'Q')		// ESCAPE
	{
		exit(0);
	}
}

bool initShaders( const char* vertShaderPath, const char* fragShaderPath )
{
	// create a program before linking shaders
	program = glCreateProgram();
	glUseProgram( program );

	// compile shader sources
	vertexShader = glCreateShader( GL_VERTEX_SHADER );
	const char* vertexShaderSource = readShader( vertShaderPath ); if(vertexShaderSource==NULL) return false;
	GLint vertexShaderLength = strlen(vertexShaderSource);
	glShaderSource( vertexShader, 1, &vertexShaderSource, &vertexShaderLength );
	glCompileShader( vertexShader );
	if(!checkShader( vertexShader, "vertexShader" )){ printf( "Unable to compile vertex shader\n" ); return false; }
	
	fragmentShader = glCreateShader( GL_FRAGMENT_SHADER );
	const char* fragmentShaderSource = readShader( fragShaderPath ); if(fragmentShaderSource==NULL) return false;
	GLint fragmentShaderLength = strlen(fragmentShaderSource);
	glShaderSource( fragmentShader, 1, &fragmentShaderSource, &fragmentShaderLength );
	glCompileShader( fragmentShader );
	if(!checkShader( fragmentShader, "fragmentShader" )){ printf( "Unable to compile fragment shader\n" ); return false; }
	
	// attach vertex/fragments shaders and link program
	glAttachShader( program, vertexShader );
	glAttachShader( program, fragmentShader );
	glLinkProgram( program );
	if(!checkProgram( program, "program" )){ printf( "Unable to link program\n" ); return false; }

	// deallocate string
	free((void*)vertexShaderSource);
	free((void*)fragmentShaderSource);

	return true;
}

void GenPlanet() {
	unsigned char* image;
	int width, height, comp;

	glEnable(GL_TEXTURE_2D);

	//Sun
	planet[0].radius = 200;
	planet[0].rot = 1.0f;
	planet[0].rev = 0.0f;
	planet[0].center = vec3(0, 0, 0);
	image = stbi_load("texture/sun.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[0]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[0]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);
	
	//Mercury
	planet[1].radius = 20;
	planet[1].rot = 1.0f;
	planet[1].rev = 1.0f;
	planet[1].center = vec3(250,0,0);
	image = stbi_load("texture/mercury.jpg", &width, &height, &comp, 0);
	
	glGenTextures(1, &planetTexture[1]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[1]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	//Venus
	planet[2].radius = 30;
	planet[2].rot = 0.9f;
	planet[2].rev = 0.9f;
	planet[2].center = vec3(333, 0, 0);
	image = stbi_load("texture/venus.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[2]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[2]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	//Earth
	planet[3].radius = 40;
	planet[3].rot = 1.0f;
	planet[3].rev = 0.8f;
	planet[3].center = vec3(500, 0, 0);
	image = stbi_load("texture/earth.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[3]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[3]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	//Mars
	planet[4].radius = 40;
	planet[4].rot = 1.0f;
	planet[4].rev = 0.8f;
	planet[4].center = vec3(750, 0, 0);
	image = stbi_load("texture/mars.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[4]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[4]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	//Jupiter
	planet[5].radius = 120;
	planet[5].rot = 1.4f;
	planet[5].rev = 0.7f;
	planet[5].center = vec3(1000, 0, 0);
	image = stbi_load("texture/jupiter.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[5]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[5]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	//Saturn
	planet[6].radius = 100;
	planet[6].rot = 1.6f;
	planet[6].rev = 0.6f;
	planet[6].center = vec3(1500, 0, 0);
	image = stbi_load("texture/saturn.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[6]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[6]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	//Uranus
	planet[7].radius = 80;
	planet[7].rot = 0.8f;
	planet[7].rev = 0.5f;
	planet[7].center = vec3(2000, 0, 0);
	image = stbi_load("texture/uranus.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[7]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[7]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	//Neptune
	planet[8].radius = 80;
	planet[8].rot = 1.0f;
	planet[8].rev = 0.45f;
	planet[8].center = vec3(2500, 0, 0);
	image = stbi_load("texture/neptune.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[8]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[8]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);
}


void GenMoon() {
	
	unsigned char* image;
	int width, height, comp;
	glEnable(GL_TEXTURE_2D);
	int i;
	for (i = 0; i < 10; i++){
		moon[i].radius = 15;
		moon[i].rot = 1.0f;
		moon[i].rev = 1.0f;
	}
	
	moon[0].parent = &planet[3];
	moon[0].center = vec3(0, 0, moon[0].parent->radius*1.5f);
	image = stbi_load("texture/moon.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[9]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[9]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);
	
	moon[1].parent = &planet[5];	//jupiter
	moon[1].center = vec3(0, 0, moon[1].parent->radius*1.5f);
	image = stbi_load("texture/pluto.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[10]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[10]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	moon[2].parent = &planet[5];	//jupiter
	moon[2].center = vec3(0, 0, -moon[5].parent->radius*1.5f);
	image = stbi_load("texture/moon.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[11]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[11]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	moon[3].parent = &planet[5];	//jupiter
	moon[3].center = vec3(moon[3].parent->radius*1.5f, 0, 0);
	image = stbi_load("texture/pluto.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[12]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[12]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	moon[4].parent = &planet[5];	//jupiter
	moon[4].center = vec3(-moon[4].parent->radius*1.5f,0, 0);
	image = stbi_load("texture/moon.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[13]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[13]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	moon[5].parent = &planet[7];	//uranus
	moon[5].center = vec3(0, 0, moon[5].parent->radius*1.5f);
	image = stbi_load("texture/pluto.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[14]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[14]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	moon[6].parent = &planet[7];	//uranus
	moon[6].center = vec3(0, 0, -moon[6].parent->radius*1.5f);
	image = stbi_load("texture/moon.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[15]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[15]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	moon[7].parent = &planet[7];	//uranus
	moon[7].center = vec3(moon[7].parent->radius*1.5f, 0, 0);
	image = stbi_load("texture/pluto.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[16]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[16]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	moon[8].rot = 0.3f;	
	moon[8].rev = 0.4f;
	moon[8].parent = &planet[8];	//neptune
	moon[8].center = vec3(0, 0, moon[8].parent->radius*1.5f);
	image = stbi_load("texture/moon.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[17]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[17]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);

	moon[9].parent = &planet[8];	//neptune
	moon[9].center = vec3(0, 0, -moon[9].parent->radius*1.5f);
	image = stbi_load("texture/pluto.jpg", &width, &height, &comp, 0);
	glGenTextures(1, &planetTexture[18]);
	glBindTexture(GL_TEXTURE_2D, planetTexture[18]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glActiveTexture(GL_TEXTURE0);
	
}


bool userInit()
{
	// init GL states
	glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );		// clear color for glClear()
	glEnable( GL_CULL_FACE );					// turn on backface culling
	glEnable( GL_DEPTH_TEST );					// turn on depth tests
	glShadeModel( GL_SMOOTH );

	// define planet information
	GenPlanet();
	GenMoon();

	// define vertex
	vertex sphere_vertex[36 * 36 * 6];
	int indexlist[36*36*6];
	int n = 0;
//	int t1, t2;
	float DTOR = PI / 180;
	float theta, phi;

	for (theta = -90; theta < 90; theta+=10) {
		for (phi = -180; phi <= 180; phi+=10) {		
			//1
			sphere_vertex[n].pos = vec3(cos(theta*DTOR)*cos(phi*DTOR),
				cos(theta*DTOR)*sin(phi*DTOR),
				sin(theta*DTOR));
			sphere_vertex[n].norm = sphere_vertex[n].pos;
			sphere_vertex[n].tex = vec2(phi / (2.0f*PI)*DTOR, (theta + 90) / PI*DTOR);
			indexlist[n] = n;
			n++;
			
			//4
			sphere_vertex[n].pos = vec3(cos(theta*DTOR)*cos((phi + 10)*DTOR),
				cos(theta*DTOR)*sin((phi + 10)*DTOR),
				sin(theta*DTOR));
			sphere_vertex[n].norm = sphere_vertex[n].pos;
			sphere_vertex[n].tex = vec2((phi + 10) / (2.0f*PI)*DTOR, (theta + 90) / PI*DTOR);
			indexlist[n] = n;
			n++;

			//2
			sphere_vertex[n].pos = vec3(cos((theta + 10)*DTOR)*cos(phi*DTOR),
				cos((theta + 10)*DTOR)*sin(phi*DTOR),
				sin((theta + 10)*DTOR));
			sphere_vertex[n].norm = sphere_vertex[n].pos;
			sphere_vertex[n].tex = vec2(phi / (2.0f*PI)*DTOR, ((theta + 10) + 90) / PI*DTOR);
			indexlist[n] = n; 
			n++;

			//4
			sphere_vertex[n].pos = vec3(cos(theta*DTOR)*cos((phi + 10)*DTOR),
				cos(theta*DTOR)*sin((phi + 10)*DTOR),
				sin(theta*DTOR));
			sphere_vertex[n].norm = sphere_vertex[n].pos;
			sphere_vertex[n].tex = vec2((phi + 10) / (2.0f*PI)*DTOR, (theta + 90) / PI*DTOR);
			indexlist[n] = n; 
			n++;
			
			//3
			sphere_vertex[n].pos = vec3(cos((theta + 10)*DTOR)*cos((phi + 10)*DTOR),
				cos((theta + 10)*DTOR)*sin((phi + 10)*DTOR),
				sin((theta + 10)*DTOR));
			sphere_vertex[n].norm = sphere_vertex[n].pos;
			sphere_vertex[n].tex = vec2((phi + 10) / (2.0f*PI)*DTOR, ((theta + 10) + 90) / PI*DTOR);
			indexlist[n] = n; 
			n++;

			//2
			sphere_vertex[n].pos = vec3(cos((theta + 10)*DTOR)*cos(phi*DTOR),
				cos((theta + 10)*DTOR)*sin(phi*DTOR),
				sin((theta + 10)*DTOR));
			sphere_vertex[n].norm = sphere_vertex[n].pos;
			sphere_vertex[n].tex = vec2(phi / (2.0f*PI)*DTOR, ((theta + 10) + 90) / PI*DTOR);
			indexlist[n] = n; 
			n++;
	
		}
	}

	// create a vertex buffer
	glGenBuffers( 1, &vertexPositionBuffer );
	glBindBuffer( GL_ARRAY_BUFFER, vertexPositionBuffer );
	glBufferData(GL_ARRAY_BUFFER, sizeof(sphere_vertex), sphere_vertex, GL_STATIC_DRAW);

	// create a index buffer
	glGenBuffers( 1,&indexBuffer );
	glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, indexBuffer );
	glBufferData( GL_ELEMENT_ARRAY_BUFFER, sizeof(indexlist), indexlist, GL_STATIC_DRAW );

	trackball.viewMatrix0 = camera.viewMatrix;
	trackball.trackballMatrix = camera.viewMatrix;

	// init camera
	camera.eye = vec3( 0, 0,2500);
	camera.at = vec3( 0, 0, 0 );
	camera.up = vec3( 0, 1, 0 );
	camera.viewMatrix = mat4::lookAt( camera.eye, camera.at, camera.up );

	// init light properties
	light.position = vec4( 0.0f, 0.0f, 0.0f, 1.0f );   // directional light
    light.ambient  = vec4( 0.2f, 0.2f, 0.2f, 1.0f );
    light.diffuse  = vec4( 0.8f, 0.8f, 0.8f, 1.0f );
    light.specular = vec4( 1.0f, 1.0f, 1.0f, 1.0f );

	// init material properties
	material.ambient  = vec4( 0.5f, 0.5f, 0.5f, 1.0f );
    material.diffuse  = vec4( 0.8f, 0.8f, 0.8f, 1.0f );
    material.specular = vec4( 1.0f, 1.0f, 1.0f, 1.0f );
	material.shininess = 100.0f;

	return true;
}

int main( int argc, char* argv[] )
{
	// change working directory to the current executable's directory
	setWorkingDirToBinDir( argv[0] );

	// GLUT initialization
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA );

	int screenWidth		= glutGet(GLUT_SCREEN_WIDTH);
	int screenHeight	= glutGet(GLUT_SCREEN_HEIGHT);
	windowWidth			= 1280;
	windowHeight		= 720;
	
	glutInitWindowSize( windowWidth, windowHeight );
	glutInitWindowPosition( (screenWidth-windowWidth)/2, (screenHeight-windowHeight)/2 );
	glutCreateWindow( "Solar System" );

	// Register callbacks
	glutDisplayFunc( display );
	glutReshapeFunc( reshape );		// callback when the window is resized
	glutKeyboardFunc( keyboard );
	glutMouseFunc( mouse );
	glutMotionFunc( motion );		// callback when the mouse is moving
	glutIdleFunc( idle );			// idle-time callback

	// init and check GLEW, version, extensions
	if(!initExtensions()){ printf( "Failed to init extensions.\n" ); return 0; }
	
	// create and compile shaders/program
	if(!initShaders("shaders/hello.vert","shaders/hello.frag")){ printf( "Failed to init program and shaders\n" ); return 0; }

	// user initialization
	if(!userInit()){ printf( "Failed to userInit()\n" ); return 0; }

	// Start rendering loop
	glutMainLoop();
	return 0;
}