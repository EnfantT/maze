#include "cgmath.h"		// slee's simple math library
#include "GL/glew.h"		// glew.sourceforge.net
#include "GL/freeglut.h"	// freeglut.sourceforge.net
#include "support.h"		// declaration for support functions
#include <time.h>

#pragma comment( lib, "OpenGL32.lib" )	// inline linking for OpenGL
#pragma comment( lib, "glew32.lib" )	// inline linking for glew
#pragma comment( lib, "freeglut.lib" )	// inline linking for freeGLUT

//*******************************************************************
// global variables
GLuint	program=0;
GLuint	vertexShader=0;
GLuint	fragmentShader=0;
GLuint	vertexBuffer=0;
GLuint	indexBuffer=0;


// circle information

struct Circle{
	vec2 center;
	vec4 color;
	float radius;
	vec2 Speed;
};

Circle circle[20];


// user flags
bool	bMouseLButtonDown=false;
GLfloat	aspectRatio = 1.5f;


//*******************************************************************
void updateUniforms()
{
	// update uniform variables
	GLuint loc0 = glGetUniformLocation( program, "aspectRatio" );
	glUniform1f( loc0, aspectRatio );

	mat4 modelMatrix;
	modelMatrix = mat4::scale(1, 1, 0) * modelMatrix;
	modelMatrix = mat4::translate(0, 0, 0) * modelMatrix;

	// update the model matrix to move the object.
	GLuint loc = glGetUniformLocation(program, "modelMatrix");
	if (loc>-1) glUniformMatrix4fv(loc, 1, GL_TRUE, modelMatrix);
}

void render()
{
	// clear screen (with background color) and clear depth buffer
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	
	// notify to GL that we like to use our program now
	glUseProgram( program );

	// bind vertex position buffer
	GLuint vertexPositionLoc = glGetAttribLocation( program, "position" );
	glEnableVertexAttribArray( vertexPositionLoc );
	glBindBuffer( GL_ARRAY_BUFFER, vertexBuffer );
	glVertexAttribPointer( vertexPositionLoc, 2, GL_FLOAT, GL_FALSE, 0, 0 );

	// render vertices: trigger shader programs to process vertex data
	glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, indexBuffer );
	

	
	float endX, endY;
	if (aspectRatio > 1.0f){
		endX = aspectRatio;
		endY = 1.0f;
	}
	else{
		endX = 1.0f;
		endY = 1.0f / aspectRatio;
	}
	srand((uint)time(NULL));
	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < i; j++) {
			if ((circle[i].center - circle[j].center).length() <= circle[i].radius + circle[j].radius) {
				vec2 temp;				

				temp = circle[i].Speed;
				circle[i].Speed = circle[j].Speed;
				circle[j].Speed = temp;				
			}
		}

		if (circle[i].center.x + circle[i].radius > endX && circle[i].Speed.x > 0.0f) 
			circle[i].Speed.x *= -1.0f;
		
		if (circle[i].center.x - circle[i].radius < -endX && circle[i].Speed.x < 0.0f) 
			circle[i].Speed.x *= -1.0f;
		
		if (circle[i].center.y + circle[i].radius > endY && circle[i].Speed.y > 0.0f) 
			circle[i].Speed.y *= -1.0f;
		
		if (circle[i].center.y - circle[i].radius < -endY && circle[i].Speed.y < 0.0f) 
			circle[i].Speed.y *= -1.0f;
	}

	for( int i = 0 ; i < 20 ; i++ ) {
		
		mat4 modelMatrix;
		modelMatrix = mat4::scale(circle[i].radius, circle[i].radius, 0) * modelMatrix;
		modelMatrix = mat4::translate(circle[i].center.x, circle[i].center.y,0) * modelMatrix;
				 
		circle[i].center += circle[i].Speed*0.001f;

		glUniformMatrix4fv( glGetUniformLocation( program, "modelMatrix" ), 1, GL_TRUE, modelMatrix );
		glUniform4f(glGetUniformLocation(program, "vertexColor"), circle[i].color.x, circle[i].color.y, circle[i].color.z, circle[i].color.w);

		glDrawElements( GL_TRIANGLES, 72*3, GL_UNSIGNED_INT, NULL );
	}

	// now swap backbuffer with front buffer, and display it
	glutSwapBuffers();
}

void display()
{
	updateUniforms();
	render();
}

void reshape( int width, int height )
{
	// set current viewport in pixels
	// viewport: the window area that are affected by rendering
	// (win_x, win_y, win_width, win_height)
	glViewport( 0, 0, width, height );

	// refresh the aspectRatio, when the window size is changed
	aspectRatio = width / float(height);

	// post signal to call display
	// this causes GL to call display() soon
	// but, we do not know exactly when dipslay() is called
	glutPostRedisplay();				
}

void mouse( int button, int state, int x, int y )
{
	if(button==GLUT_LEFT_BUTTON)
	{
		bMouseLButtonDown = (state==GLUT_DOWN);
		if(bMouseLButtonDown) printf( "Left mouse button pressed at (%d, %d)\n", x, y );
	}
}

void motion( int x, int y )
{
}

void idle()
{
	glutPostRedisplay();	
}

void keyboard( unsigned char key, int x, int y )
{
	if(key==27||key=='q'||key=='Q')		// ESCAPE
	{
		exit(0);
	}
}

bool initShaders( const char* vertShaderPath, const char* fragShaderPath )
{
	// create a program before linking shaders
	program = glCreateProgram();
	glUseProgram( program );

	// compile shader sources
	vertexShader = glCreateShader( GL_VERTEX_SHADER );
	const char* vertexShaderSource = readShader( vertShaderPath ); if(vertexShaderSource==NULL) return false;
	GLint vertexShaderLength = strlen(vertexShaderSource);
	glShaderSource( vertexShader, 1, &vertexShaderSource, &vertexShaderLength );
	glCompileShader( vertexShader );
	if(!checkShader( vertexShader, "vertexShader" )){ printf( "Unable to compile vertex shader\n" ); return false; }
	
	fragmentShader = glCreateShader( GL_FRAGMENT_SHADER );
	const char* fragmentShaderSource = readShader( fragShaderPath ); if(fragmentShaderSource==NULL) return false;
	GLint fragmentShaderLength = strlen(fragmentShaderSource);
	glShaderSource( fragmentShader, 1, &fragmentShaderSource, &fragmentShaderLength );
	glCompileShader( fragmentShader );
	if(!checkShader( fragmentShader, "fragmentShader" )){ printf( "Unable to compile fragment shader\n" ); return false; }
	
	// attach vertex/fragments shaders and link program
	glAttachShader( program, vertexShader );
	glAttachShader( program, fragmentShader );
	glLinkProgram( program );
	if(!checkProgram( program, "program" )){ printf( "Unable to link program\n" ); return false; }

	// deallocate string
	free((void*)vertexShaderSource);
	free((void*)fragmentShaderSource);

	return true;
}

bool userInit()
{
	// init GL states
	glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );		// clear color for glClear()
	glEnable( GL_CULL_FACE );					// turn on backface culling
	glEnable( GL_DEPTH_TEST );					// turn on depth tests

	// create a vertex array for a circle position
	// default viewing volume: [-1~1, -1~1, -1~1]
	float	theta = 0;
	vec2	circleVert[72+1];
	GLuint	IBA[72*3];

	for (int i = 0; i < 72; i++){
		circleVert[i] = vec2(cos(theta), sin(theta));
		theta += PI / 36;

		IBA[i * 3] = 72;
		IBA[i * 3 + 1] = i;
		IBA[i * 3 + 2] = (i + 1) % 72;
	}
	circleVert[72] = vec2(0.0, 0.0);

	// geneation of vertex buffer
	glGenBuffers( 1, &vertexBuffer );
	glBindBuffer( GL_ARRAY_BUFFER, vertexBuffer );
	glBufferData( GL_ARRAY_BUFFER, sizeof(circleVert), circleVert, GL_STATIC_DRAW );

	// geneation of index buffer
	glGenBuffers( 1, &indexBuffer );
	glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, indexBuffer );
	glBufferData( GL_ELEMENT_ARRAY_BUFFER, sizeof(IBA), IBA, GL_STATIC_DRAW );

	// set the initial condition of each circle
	srand((uint)time(NULL));

	
	for (int i = 0; i < 20; i++) {
		float X = 0.1f*(10 - rand() % 21);
		float Y = 0.05f*(10 - rand() % 21);
		float R = 0.01f*(rand() % 20 + 5);
		
		circle[i].center = vec2(X, Y);
		circle[i].radius = R;		
		circle[i].color = vec4(0.01f*(rand() % 101), 0.01f*(rand() % 101), 0.01f*(rand() % 101), 0);
		circle[i].Speed = vec2(0.01f*(100 - rand() % 201), 0.01f*(100 - rand() % 201));

		for (int j = 0; j < i; j++){
			bool out = false;
		
			if (circle[i].center.x + circle[i].radius >(aspectRatio - 0.1f))
				out = true;				
			if(circle[i].center.x - circle[i].radius < -(aspectRatio-0.1f))
				out = true;
			if (circle[i].center.y + circle[i].radius > 0.9f)
				out = true;
			if (circle[i].center.y - circle[i].radius < -0.9f)
				out = true;

			if (out || (circle[i].center - circle[j].center).length() <= circle[i].radius + circle[j].radius) {
				X = 0.1f*(10 - rand() % 21);
				Y = 0.05f*(10 - rand() % 21);
				circle[i].center = vec2(X,Y);
				circle[i].radius = 0.01f*(rand() % 20 + 5);
				j = -1;
			}
		}

		
	}

	return true;
}

int main( int argc, char* argv[] )
{
	setWorkingDirToBinDir( argv[0] );					// change working directory to the current' binary's directory

	// GLUT initialization
	glutInit( &argc, argv );							// default initialization for GLUT
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA );		// double buffering with RGBA frame buffer

	int screenWidth = glutGet(GLUT_SCREEN_WIDTH);
	int screenHeight = glutGet(GLUT_SCREEN_HEIGHT);
	int windowWidth = 720;
	int windowHeight = 480;

	glutInitWindowSize(windowWidth, windowHeight);
	glutInitWindowPosition((screenWidth - windowWidth) / 2, (screenHeight - windowHeight) / 2);
	glutCreateWindow("Moving Circles");

	// Register callbacks
	glutDisplayFunc( display );		// callback when window is drawing
	glutReshapeFunc( reshape );		// callback when window is resized
	glutKeyboardFunc( keyboard );	// callback for keyboard input
	glutMouseFunc( mouse );			// callback for mouse click input
	glutMotionFunc( motion );		// callback for mouse movement input
	glutIdleFunc( idle );			// callback for idle time

	// init and check GLEW, version, extensions
	if(!initExtensions()){ printf( "Failed to init extensions.\n" ); return 0; }
	
	// create and compile shaders/program
	if(!initShaders("shaders/hello.vert","shaders/hello.frag")){ printf( "Failed to init program and shaders\n" ); return 0; }

	// user initialization
	if(!userInit()){ printf( "Failed to userInit()\n" ); return 0; }

	// Start rendering loop
	glutMainLoop();					// enters into rendering loop
	return 0;
}
