#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "cgmath-min.h"		// plug your "cgmath-min.h" file into here

inline float rnd(){ static unsigned int c=0; if(c==0){ srand( (unsigned int)time(NULL) ); c++; } return float(rand()%100+1); }

unsigned int score		= 0;
unsigned int vec2Score	= 0;
unsigned int vec3Score	= 0;
unsigned int vec4Score	= 0;
unsigned int mat4Score	= 0;
unsigned int vec2Total	= 0;
unsigned int vec3Total	= 0;
unsigned int vec4Total	= 0;
unsigned int mat4Total	= 0;
unsigned int total		= 0;

static const float TH = 0.00001f;
#define TEST1(a,b )				{ int s=fabs((a)-(b))<TH?1:0; total++; score+=s; if(!s)printf( "[%c] %s=%.1f, %s=%.1f\n", s?'O':'X', #a, (a), #b, (b) ); }
#define TEST2(a,b,c,d)			{ int s=fabs((a)-(b))<TH&&fabs((c)-(d))<TH?1:0; total++; score+=s; if(!s)printf( "[%c] %s=%.1f, %s=%.1f, %s=%.1f, %s=%.1f\n", s?'O':'X', #a, (a), #b, (b), #c, (c), #d, (d) ); }
#define TEST3(a,b,c,d,e,f)		{ int s=fabs((a)-(b))<TH&&fabs((c)-(d))<TH&&fabs((e)-(f))<TH?1:0; total++; score+=s; if(!s)printf( "[%c] %s=%.1f, %s=%.1f, %s=%.1f, %s=%.1f, %s=%.1f, %s=%.1f\n", s?'O':'X', #a, (a), #b, (b), #c, (c), #d, (d), #e, (e), #f, (f) ); }
#define TEST4(a,b,c,d,e,f,g,h )	{ int s=fabs((a)-(b))<TH&&fabs((c)-(d))<TH&&fabs((e)-(f))<TH&&fabs((g)-(h))<TH?1:0; total++; score+=s; if(!s)printf( "[%c] %s=%.1f, %s=%.1f, %s=%.1f, %s=%.1f, %s=%.1f, %s=%.1f, %s=%.1f, %s=%.1f\n", s?'O':'X', #a, (a), #b, (b), #c, (c), #d, (d), #e, (e), #f, (f), #g, (g), #h, (h) ); }

void main( int argc, char* argv[] )
{
	//***************************************************************
	// test functions
	printf("\n----- vec2Test -----\n"); void vec2Test(); vec2Test();
	printf("\n----- vec3Test -----\n"); void vec3Test(); vec3Test();
	printf("\n----- vec4Test -----\n"); void vec4Test(); vec4Test();
	printf("\n----- mat4Test -----\n"); void mat4Test(); mat4Test();
	
	//***************************************************************
	printf( "\n*******************\n" );
	printf( "Statistics\n\n" );
	printf( "vec2 : %d/%d passed\n", vec2Score, vec2Total );
	printf( "vec3 : %d/%d passed\n", vec3Score, vec3Total );
	printf( "vec4 : %d/%d passed\n", vec4Score, vec4Total );
	printf( "mat4 : %d/%d passed\n", mat4Score, mat4Total );
	printf( "Total : %d/%d passed\n", vec2Score+vec3Score+vec4Score+mat4Score, vec2Total+vec3Total+vec4Total+mat4Total );
	printf( "*******************\n" );
}

void vec2Test()
{
	score = 0; total = 0;

	float zero = 0.0f;
	float float2[2] = {rnd(), rnd()};
	vec2 tv;
	vec2 tv2;
	float tf = rnd();
	
	// array operator overloading test
	vec2 arv = vec2(rnd(), rnd()); const vec2 carv = vec2(rnd(), rnd());  
	TEST2( arv[0], arv.x, arv[1], arv.y );
	TEST2( carv[0], carv.x, carv[1], carv.y );

	// unary operators
	vec2 uv = vec2(rnd(), rnd()); const vec2 cuv = vec2(rnd(), rnd());
	tv = +uv;	TEST2( tv.x, uv.x, tv.y, uv.y );	
	tv = -uv;	TEST2( tv.x, -uv.x, tv.y, -uv.y );	
	tv = +cuv;	TEST2( tv.x, cuv.x, tv.y, cuv.y );
	tv = -cuv;	TEST2( tv.x, -cuv.x, tv.y, -cuv.y );

	// four fundametal arithmetic operator overloading test
	vec2 av = vec2(rnd(), rnd()); const vec2 cav = vec2(rnd(), rnd()); tv.set(20.0f, 25.0f); tf = rnd();
	tv2 = tv+cav; TEST2( tv2.x, tv.x+cav.x, tv2.y, tv.y+cav.y );
	tv2 = tv-cav; TEST2( tv2.x, tv.x-cav.x, tv2.y, tv.y-cav.y );
	tv2 = tv*cav; TEST2( tv2.x, tv.x*cav.x, tv2.y, tv.y*cav.y );
	tv2 = tv/cav; TEST2( tv2.x, tv.x/cav.x, tv2.y, tv.y/cav.y );
	tv2 = cav+tv; TEST2( tv2.x, cav.x+tv.x, tv2.y, cav.y+tv.y );
	tv2 = cav-tv; TEST2( tv2.x, cav.x-tv.x, tv2.y, cav.y-tv.y );
	tv2 = cav*tv; TEST2( tv2.x, cav.x*tv.x, tv2.y, cav.y*tv.y );
	tv2 = cav/tv; TEST2( tv2.x, cav.x/tv.x, tv2.y, cav.y/tv.y );
	tv2 = av*tf; TEST2( tv2.x, av.x*tf, tv2.y, av.y*tf );
	tv2 = av/tf; TEST2( tv2.x, av.x/tf, tv2.y, av.y/tf );

	// length method test
	vec2 lv = vec2(3.0f, 4.0f); // these numbers will change later
	TEST1( lv.length(), 5.0f );

	// dot product test
	vec2 dv = vec2(rnd(), rnd()); const vec2 constdotVec = vec2(rnd(), rnd());
	tf = dv.dot(constdotVec);
	TEST1( tf, dv.x*constdotVec.x+dv.y*constdotVec.y );
	tf = dot(dv, dv);
	TEST1( tf, dv.x*dv.x+dv.y*dv.y );

	// normalize method test
	vec2 nv = vec2(rnd(), rnd());
	tv = nv.normalize();
	TEST1( tv.length(), 1.0f );

	// record the current score
	vec2Score = score; vec2Total = total;
}

void vec3Test()
{
	score = 0; total = 0;

	float zero = 0.0f;
	float float3[3] = {rnd(), rnd(), rnd()};
	vec3 tv;
	vec3 tv2;
	float tf = rnd();
	
	// array operator overloading test
	vec3 arv = vec3(rnd(), rnd(), rnd()); const vec3 carv = vec3(rnd(), rnd(), rnd());  
	TEST3( arv[0], arv.x, arv[1], arv.y, arv[2], arv.z );
	TEST3( carv[0], carv.x, carv[1], carv.y, carv[2], carv.z );
	
	// unary operators
	vec3 uv = vec3(rnd(), rnd(), rnd()); const vec3 cuv = vec3(rnd(), rnd(), rnd());
	tv = +uv;	TEST3( tv.x, uv.x, tv.y, uv.y, tv.z, uv.z );	
	tv = -uv;	TEST3( tv.x, -uv.x, tv.y, -uv.y, tv.z, -uv.z );	
	tv = +cuv;	TEST3( tv.x, cuv.x, tv.y, cuv.y, tv.z, cuv.z );	
	tv = -cuv;	TEST3( tv.x, -cuv.x, tv.y, -cuv.y, tv.z, -cuv.z );

	// four fundametal arithmetic operator overloading test
	vec3 av = vec3(rnd(), rnd(), rnd()); const vec3 cav = vec3(rnd(), rnd(), rnd()); tv.set(rnd(), rnd(), rnd()); tf = rnd();
	tv2 = tv+cav; TEST3( tv2.x, tv.x+cav.x, tv2.y, tv.y+cav.y, tv2.z, tv.z+cav.z );
	tv2 = tv-cav; TEST3( tv2.x, tv.x-cav.x, tv2.y, tv.y-cav.y, tv2.z, tv.z-cav.z );
	tv2 = tv*cav; TEST3( tv2.x, tv.x*cav.x, tv2.y, tv.y*cav.y, tv2.z, tv.z*cav.z );
	tv2 = tv/cav; TEST3( tv2.x, tv.x/cav.x, tv2.y, tv.y/cav.y, tv2.z, tv.z/cav.z );
	tv2 = cav+tv; TEST3( tv2.x, cav.x+tv.x, tv2.y, cav.y+tv.y, tv2.z, cav.z+tv.z );
	tv2 = cav-tv; TEST3( tv2.x, cav.x-tv.x, tv2.y, cav.y-tv.y, tv2.z, cav.z-tv.z );
	tv2 = cav*tv; TEST3( tv2.x, cav.x*tv.x, tv2.y, cav.y*tv.y, tv2.z, cav.z*tv.z );
	tv2 = cav/tv; TEST3( tv2.x, cav.x/tv.x, tv2.y, cav.y/tv.y, tv2.z, cav.z/tv.z );
	tv2 = av*tf; TEST3( tv2.x, av.x*tf, tv2.y, av.y*tf, tv2.z, av.z*tf );
	tv2 = av/tf; TEST3( tv2.x, av.x/tf, tv2.y, av.y/tf, tv2.z, av.z/tf );

	// length method test
	vec3 lv = vec3(3.0f, 4.0f, 0.0f); // these numbers will change later
	TEST1( lv.length(), 5.0f );

	// dot product test
	vec3 dv = vec3(rnd(), rnd(), rnd()); const vec3 constdotVec = vec3(rnd(), rnd(), rnd());
	tf = dv.dot(constdotVec);
	TEST1(tf, dv.x*constdotVec.x+dv.y*constdotVec.y+dv.z*constdotVec.z);
	tf = dot(dv, dv);
	TEST1(tf, dv.x*dv.x+dv.y*dv.y+dv.z*dv.z);
	
	// normalize method test
	vec3 nv = vec3(rnd(), rnd(), rnd());
	tv = nv.normalize();
	TEST1( tv.length(), 1.0f );

	// cross product test (vec3 only)
	vec3 crsv = vec3(rnd(), rnd(), rnd()); const vec3 ccv = vec3(rnd(), rnd(), rnd()); vec3 res;
	res = crsv^ccv;
	TEST3( res.x, crsv.y*ccv.z-crsv.z*ccv.y, res.y, crsv.z*ccv.x-crsv.x*ccv.z, res.z, crsv.x*ccv.y-crsv.y*ccv.x );
	crsv.set(rnd(), rnd(), rnd());	res = ccv^crsv;
	TEST3( res.x, ccv.y*crsv.z-ccv.z*crsv.y, res.y, ccv.z*crsv.x-ccv.x*crsv.z, res.z, ccv.x*crsv.y-ccv.y*crsv.x );
	
	res = crsv.cross(ccv);
	TEST3( res.x, crsv.y*ccv.z-crsv.z*ccv.y, res.y, crsv.z*ccv.x-crsv.x*ccv.z, res.z, crsv.x*ccv.y-crsv.y*ccv.x );
	crsv.set(rnd(), rnd(), rnd());	res = ccv.cross(crsv);
	TEST3( res.x, ccv.y*crsv.z-ccv.z*crsv.y, res.y, ccv.z*crsv.x-ccv.x*crsv.z, res.z, ccv.x*crsv.y-ccv.y*crsv.x );
	
	// record the current score
	vec3Score = score; vec3Total = total;
}

void vec4Test()
{
	score = 0; total = 0;

	float zero = 0.0f;
	float float4[4] = {rnd(), rnd(), rnd(), rnd()};
	vec4 tv;
	vec4 tv2;
	float tf = rnd();
	
	// array operator overloading test
	vec4 arv = vec4(rnd(), rnd(), rnd(), rnd()); const vec4 carv = vec4(rnd(), rnd(), rnd(), rnd());  
	TEST4( arv[0], arv.x, arv[1], arv.y, arv[2], arv.z, arv[3], arv.w );
	TEST4( carv[0], carv.x, carv[1], carv.y, carv[2], carv.z, carv[3], carv.w );
	
	// unary operators
	vec4 uv = vec4(rnd(), rnd(), rnd(), rnd()); const vec4 cuv = vec4(rnd(), rnd(), rnd(), rnd());
	tv = +uv;	TEST4( tv.x, uv.x, tv.y, uv.y, tv.z, uv.z, tv.w, uv.w );	
	tv = -uv;	TEST4( tv.x, -uv.x, tv.y, -uv.y, tv.z, -uv.z, tv.w, -uv.w );	
	tv = +cuv;	TEST4( tv.x, cuv.x, tv.y, cuv.y, tv.z, cuv.z, tv.w, cuv.w );	
	tv = -cuv;	TEST4( tv.x, -cuv.x, tv.y, -cuv.y, tv.z, -cuv.z, tv.w, -cuv.w );

	// four fundametal arithmetic operator overloading test
	vec4 av = vec4(rnd(), rnd(), rnd(), rnd()); const vec4 cav = vec4(rnd(), rnd(), rnd(), rnd()); tv.set(rnd(), rnd(), rnd(), rnd()); tf = rnd();
	tv2 = tv+cav; TEST4( tv2.x, tv.x+cav.x, tv2.y, tv.y+cav.y, tv2.z, tv.z+cav.z, tv2.w, tv.w+cav.w );
	tv2 = tv-cav; TEST4( tv2.x, tv.x-cav.x, tv2.y, tv.y-cav.y, tv2.z, tv.z-cav.z, tv2.w, tv.w-cav.w );
	tv2 = tv*cav; TEST4( tv2.x, tv.x*cav.x, tv2.y, tv.y*cav.y, tv2.z, tv.z*cav.z, tv2.w, tv.w*cav.w );
	tv2 = tv/cav; TEST4( tv2.x, tv.x/cav.x, tv2.y, tv.y/cav.y, tv2.z, tv.z/cav.z, tv2.w, tv.w/cav.w );
	tv2 = cav+tv; TEST4( tv2.x, cav.x+tv.x, tv2.y, cav.y+tv.y, tv2.z, cav.z+tv.z, tv2.w, cav.w+tv.w );
	tv2 = cav-tv; TEST4( tv2.x, cav.x-tv.x, tv2.y, cav.y-tv.y, tv2.z, cav.z-tv.z, tv2.w, cav.w-tv.w );
	tv2 = cav*tv; TEST4( tv2.x, cav.x*tv.x, tv2.y, cav.y*tv.y, tv2.z, cav.z*tv.z, tv2.w, cav.w*tv.w );
	tv2 = cav/tv; TEST4( tv2.x, cav.x/tv.x, tv2.y, cav.y/tv.y, tv2.z, cav.z/tv.z, tv2.w, cav.w/tv.w );
	tv2 = av*tf; TEST4( tv2.x, av.x*tf, tv2.y, av.y*tf, tv2.z, av.z*tf, tv2.w, av.w*tf );
	tv2 = av/tf; TEST4( tv2.x, av.x/tf, tv2.y, av.y/tf, tv2.z, av.z/tf, tv2.w, av.w/tf );

	// length method test
	vec4 lv = vec4(3.0f, 4.0f, 0.0f, 0.0f); // these numbers will change later
	TEST1( lv.length(), 5.0f );

	// dot product test
	vec4 dv = vec4(rnd(), rnd(), rnd(), rnd()); const vec4 constdotVec = vec4(rnd(), rnd(), rnd(), rnd());
	tf = dv.dot(constdotVec);
	TEST1( tf, dv.x*constdotVec.x+dv.y*constdotVec.y+dv.z*constdotVec.z+dv.w*constdotVec.w );
	tf = dot(dv, dv); // dot() is a global function
	TEST1( tf, dv.x*dv.x+dv.y*dv.y+dv.z*dv.z+dv.w*dv.w );

	// normalize test
	vec4 nv = vec4(rnd(), rnd(), rnd(), rnd());
	tv = nv.normalize();
	TEST1( tv.length(), 1.0f );

	// record the current score
	vec4Score = score; vec4Total = total;
}

void mat4Test()
{
	score = 0; total = 0;

	float identity[16] = { 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f };
	mat4 tm1, tm2;
	vec4 tv1, tv2;
		
	// array operator test
	mat4 am = mat4( rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd() );
	const mat4 cam = mat4( rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd() );
	TEST4( am.a[0], am[0], am.a[1], am[1], am.a[2], am[2], am.a[3], am[3] );
	TEST4( am.a[4], am[4], am.a[5], am[5], am.a[6], am[6], am.a[7], am[7] );
	TEST4( am.a[8], am[8], am.a[9], am[9], am.a[10], am[10], am.a[11], am[11] ); 
	TEST4( am.a[12], am[12], am.a[13], am[13], am.a[14], am[14], am.a[15], am[15] ); 
	TEST4( cam.a[0], cam[0], cam.a[1], cam[1], cam.a[2], cam[2], cam.a[3], cam[3] ); 
	TEST4( cam.a[4], cam[4], cam.a[5], cam[5], cam.a[6], cam[6], cam.a[7], cam[7] );
	TEST4( cam.a[8], cam[8], cam.a[9], cam[9], cam.a[10], cam[10], cam.a[11], cam[11] );
	TEST4( cam.a[12], cam[12], cam.a[13], cam[13], cam.a[14], cam[14], cam.a[15], cam[15] );
		
	// basic operation test : transpose(), setIdentity()
	mat4 bom[2] =	{
						mat4( rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd() ),
						mat4( rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd() )
					};

	bom[0].setIdentity(); tm1 = bom[1].transpose();
	TEST4( bom[0].a[0], identity[0], bom[0].a[1], identity[1], bom[0].a[2], identity[2], bom[0].a[3], identity[3] ); 
	TEST4( bom[0].a[4], identity[4], bom[0].a[5], identity[5], bom[0].a[6], identity[6], bom[0].a[7], identity[7] ); 
	TEST4( bom[0].a[8], identity[8], bom[0].a[9], identity[9], bom[0].a[10], identity[10], bom[0].a[11], identity[11] ); 
	TEST4( bom[0].a[12], identity[12], bom[0].a[13], identity[13], bom[0].a[14], identity[14], bom[0].a[15], identity[15] );
	TEST4( bom[1].a[0], tm1.a[0], bom[1].a[1], tm1.a[4], bom[1].a[2], tm1.a[8], bom[1].a[3], tm1.a[12] );
	TEST4( bom[1].a[4], tm1.a[1], bom[1].a[5], tm1.a[5], bom[1].a[6], tm1.a[9], bom[1].a[7], tm1.a[13] );
	TEST4( bom[1].a[8], tm1.a[2], bom[1].a[9], tm1.a[6], bom[1].a[10], tm1.a[10], bom[1].a[11], tm1.a[14] );
	TEST4( bom[1].a[12], tm1.a[3], bom[1].a[13], tm1.a[7], bom[1].a[14], tm1.a[11], bom[1].a[15], tm1.a[15] );
	
	// matrix binary operator test
	tv1 = vec4( 37.0f, 3.0f, 85.0f, 11.0f ); // these numbers will change later
	mat4 bm[2] =	{
						mat4( 1.0f, 2.0f, 3.0f, 3.0f, 1.0f, 2.0f, 4.0f, 1.0f, 3.0f, 1.0f, 2.0f, 4.0f, 5.0f, 7.0f, 3.0f, 2.0f ), // these numbers will change later
						mat4( 12.0f, 14.0f, 12.0f, 3.0f, 7.0f, 9.0f, 11.0f, 10.0f, 2.0f, 7.0f, 8.0f, 9.0f, 11.0f, 1.0f, 1.0f, 3.0f )  // these numbers will change later
					};
	
	tv2 = bm[0]*tv1;
	TEST1( tv2.x, 331.0f ); TEST1( tv2.y, 394.0f ); TEST1( tv2.z, 328.0f ); TEST1( tv2.w, 483.0f );
 	
	tm1 = bm[0]*bm[1];
	tm2 = mat4( 65.0f, 56.0f, 61.0f, 59.0f, 45.0f, 61.0f, 67.0f, 62.0f, 91.0f, 69.0f, 67.0f, 49.0f, 137.0f, 156.0f, 163.0f, 118.0f ); // these numbers will change later
	TEST4( tm1.a[0], tm2.a[0], tm1.a[1], tm2.a[1], tm1.a[2], tm2.a[2], tm1.a[3], tm2.a[3] );
	TEST4( tm1.a[4], tm2.a[4], tm1.a[5], tm2.a[5], tm1.a[6], tm2.a[6], tm1.a[7], tm2.a[7] );
	TEST4( tm1.a[8], tm2.a[8], tm1.a[9], tm2.a[9], tm1.a[10], tm2.a[10], tm1.a[11], tm2.a[11] );
	TEST4( tm1.a[12], tm2.a[12], tm1.a[13], tm2.a[13], tm1.a[14], tm2.a[14], tm1.a[15], tm2.a[15] );
	
	// determinant test
	mat4 detMat = mat4( 12.0f, 14.0f, 12.0f, 3.0f, 7.0f, 14.0f, 11.0f, 10.0f, 2.0f, 8.0f, 8.0f, 9.0f, 12.0f, 1.0f, 1.0f, 3.0f ); // these numbers will change later
	TEST1( detMat.determinant(), 2792.0f );
		
	// inverse test
	mat4 im = mat4( 1.0f, 2.0f, 3.0f, 3.0f, 1.0f, 2.0f, 4.0f, 1.0f, 3.0f, 1.0f, 2.0f, 4.0f, 5.0f, 7.0f, 3.0f, 2.0f );
	
	tm1 = im.inverse();
	tm2 = tm1.inverse();
	TEST4( im.a[0], tm2.a[0], im.a[1], tm2.a[1], im.a[2], tm2.a[2], im.a[3], tm2.a[3] );
	TEST4( im.a[4], tm2.a[4], im.a[5], tm2.a[5], im.a[6], tm2.a[6], im.a[7], tm2.a[7] );
	TEST4( im.a[8], tm2.a[8], im.a[9], tm2.a[9], im.a[10], tm2.a[10], im.a[11], tm2.a[11] );
	TEST4( im.a[12], tm2.a[12], im.a[13], tm2.a[13], im.a[14], tm2.a[14], im.a[15], tm2.a[15] );
	
	tm2 = tm2.inverse();
	TEST4( tm1.a[0], tm2.a[0], tm1.a[1], tm2.a[1], tm1.a[2], tm2.a[2], tm1.a[3], tm2.a[3] );
	TEST4( tm1.a[4], tm2.a[4], tm1.a[5], tm2.a[5], tm1.a[6], tm2.a[6], tm1.a[7], tm2.a[7] );
	TEST4( tm1.a[8], tm2.a[8], tm1.a[9], tm2.a[9], tm1.a[10], tm2.a[10], tm1.a[11], tm2.a[11] );
	TEST4( tm1.a[12], tm2.a[12], tm1.a[13], tm2.a[13], tm1.a[14], tm2.a[14], tm1.a[15], tm2.a[15] );
		
	mat4Score = score; mat4Total = total;
}
