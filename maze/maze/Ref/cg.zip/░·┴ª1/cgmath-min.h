#pragma once
//###################################################################
// C standard library
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
// C++ STL
#include <algorithm>
#include <map>
#include <set>
#include <string>
#include <vector>
// windows
#if !defined(__GNUC__)&&(defined(_WIN32)||defined(_WIN64))
	#include <windows.h>
	#include <wchar.h>
#endif
// user types
typedef unsigned int	uint;
typedef unsigned char	uchar;
typedef unsigned short	ushort;
//###################################################################

template <class T> struct tvec2
{
	union{ struct { T r, g; }; struct { T x, y; }; };

	// constructor/set
	tvec2(){ x=y=0; }
	tvec2( T a ){ x=y=a; }						inline void set( T a ){ x=y=a; }
	tvec2( T a, T b ){ x=a;y=b; }				inline void set( T a, T b ){ x=a;y=b; }
	tvec2( const tvec2& v ){ x=v.x;y=v.y; }		inline void set( const tvec2& v ){ x=v.x;y=v.y; }
	tvec2( const T* a ){ x=a[0];y=a[1]; }		inline void set( const T* a ){ x=a[0];y=a[1]; }

	// assignment
	inline tvec2& operator=( T a ){ set(a); return *this; }
	inline tvec2& operator+=( const tvec2& v ){ x+=v.x; y+=v.y; return *this; }
	inline tvec2& operator-=( const tvec2& v ){ x-=v.x; y-=v.y; return *this; }
	inline tvec2& operator*=( const tvec2& v ){ x*=v.x; y*=v.y; return *this; }
	inline tvec2& operator/=( const tvec2& v ){ x/=v.x; y/=v.y; return *this; }
	inline tvec2& operator+=( T a ){ x+=a; y+=a; return *this; }
	inline tvec2& operator-=( T a ){ x-=a; y-=a; return *this; }
	inline tvec2& operator*=( T a ){ x*=a; y*=a; return *this; }
	inline tvec2& operator/=( T a ){ x/=a; y/=a; return *this; }

	// casting
	inline operator T*(){ return &x; }
	inline operator const T*() const { return &x; }

	// array operator
	inline T& operator[]( int i ){ 
		if (i == 0)
			return x;
		if (i == 1)
			return y;
	}
	inline const T& operator[](int i) const {		
		if (i == 0)
			return x;
		if (i == 1)
			return y;
	}
	inline T& at(int i){
		if (i == 0)
			return x;
		if (i == 1)
			return y;
	}
	inline const T& at( int i ) const { 
		if (i == 0)
			return x;
		if (i == 1)
			return y;
	}

	// unary operators
	inline tvec2 operator+(){ 
		tvec2 temp(x, y);
		return temp;
	}
	inline tvec2 operator+() const { 
		tvec2 temp(x, y);
		return temp;
	}
	inline tvec2 operator-(){ 
		tvec2 temp(-x, -y);
		return temp;
	}
	inline tvec2 operator-() const {
		tvec2 temp(-x, -y);
		return temp;
	}

	// binary operators
	inline tvec2 operator+( const tvec2& v ) const {
		tvec2 temp(x + v.x, y + v.y);
		return temp;
	}
	inline tvec2 operator-( const tvec2& v ) const { 
		tvec2 temp(x - v.x, y - v.y);
		return temp;
	}
	inline tvec2 operator*( const tvec2& v ) const { 
		tvec2 temp(x*v.x, y*v.y);
		return temp;
	}
	inline tvec2 operator/( const tvec2& v ) const { 
		tvec2 temp(x / v.x, y / v.y);
		return temp;
	}
	inline tvec2 operator+( T a ) const { 
		tvec2 temp(x + a, y + a);
		return temp;
	}
	inline tvec2 operator-( T a ) const { 
		tvec2 temp(x - a, y - a);
		return temp;
	}
	inline tvec2 operator*( T a ) const { 
		tvec2 temp(x*a, y*a);
		return temp;
	}
	inline tvec2 operator/( T a ) const { 
		tvec2 temp(x / a, y / a);
		return temp;
	}

	// length, normalize, dot product
	inline T length(){ 
		return sqrt((x*x) + (y*y));
	}
	inline T dot( const tvec2& v ) const { 
		return (x*v.x + y*v.y);
	}
	inline tvec2 normalize(){ 
		tvec2 temp(x / length(), y / length());
		return temp;
	}
};

template <class T> struct tvec3
{
	union { struct { T r, g, b; }; struct { T x, y, z; }; };

	// constructor/set
	tvec3(){ x=y=z=0; }
	tvec3( T a ){ x=y=z=a; }								inline void set( T a ){ x=y=z=a; }
	tvec3( T a, T b, T c ){ x=a;y=b;z=c; }					inline void set( T a, T b, T c ){ x=a;y=b;z=c; }
	tvec3( const tvec3& v ){ x=v.x;y=v.y;z=v.z; }			inline void set( const tvec3& v ){ x=v.x;y=v.y;z=v.z; }
	tvec3( const T* a ){ x=a[0];y=a[1];z=a[2]; }			inline void set( const T* a ){ x=a[0];y=a[1];z=a[2]; }
	tvec3( const tvec2<T>& v, T c ){ x=v.x;y=v.y;z=c; }		inline void set( const tvec2<T>& v, T c ){ x=v.x;y=v.y;z=c; }
	tvec3( T a, const tvec2<T>& v ){ x=a;y=v.x;z=v.y; }		inline void set( T a, const tvec2<T>& v ){ x=a;y=v.x;z=v.y; }

	// assignment
	inline tvec3& operator=( T a ){ set(a); return *this; }
	inline tvec3& operator=( const T* a ){ set(a); return *this; }
	inline tvec3& operator+=( const tvec3& v ){ x+=v.x; y+=v.y; z+=v.z; return *this; }
	inline tvec3& operator-=( const tvec3& v ){ x-=v.x; y-=v.y; z-=v.z; return *this; }
	inline tvec3& operator*=( const tvec3& v ){ x*=v.x; y*=v.y; z*=v.z; return *this; }
	inline tvec3& operator/=( const tvec3& v ){ x/=v.x; y/=v.y; z/=v.z; return *this; }
	inline tvec3& operator+=( T a ){ x+=a; y+=a; z+=a; return *this; }
	inline tvec3& operator-=( T a ){ x-=a; y-=a; z-=a; return *this; }
	inline tvec3& operator*=( T a ){ x*=a; y*=a; z*=a; return *this; }
	inline tvec3& operator/=( T a ){ x/=a; y/=a; z/=a; return *this; }

	// casting
	inline operator T*(){ return &x; }
	inline operator const T*(){ return &x; }

	// array operator
	inline T& operator[](int i){
		if (i == 0)
			return x;
		if (i == 1)
			return y;
		if (i == 2)
			return z;
	}
	inline const T& operator[](int i) const {
		if (i == 0)
			return x;
		if (i == 1)
			return y;
		if (i == 2)
			return z;
	}
	inline T& at( int i ){ 
		if (i == 0)
			return x;
		if (i == 1)
			return y;
		if (i == 2)
			return z;
	}
	inline const T& at( int i ) const { 
		if (i == 0)
			return x;
		if (i == 1)
			return y;
		if (i == 2)
			return z;
	}
	
	// unary operators
	inline tvec3 operator+(){ 
		tvec3 temp(x, y, z);
		return temp;
	}
	inline tvec3 operator+() const { 
		tvec3 temp(x, y, z);
		return temp;
	}
	inline tvec3 operator-(){ 
		tvec3 temp(-x, -y, -z);
		return temp;
	}
	inline tvec3 operator-() const { 
		tvec3 temp(-x, -y, -z);
		return temp;
	}

	// binary operators
	inline tvec3 operator+( const tvec3& v ) const { 
		tvec3 temp(x+v.x, y+v.y, z+v.z);
		return temp;
	}
	inline tvec3 operator-( const tvec3& v ) const { 
		tvec3 temp(x - v.x, y - v.y, z - v.z);
		return temp;
	}
	inline tvec3 operator*(const tvec3& v) const {
		tvec3 temp(x * v.x, y * v.y, z * v.z);
		return temp;
	}
	inline tvec3 operator/(const tvec3& v) const {
		tvec3 temp(x / v.x, y / v.y, z / v.z);
		return temp;
	}
	inline tvec3 operator+(T a) const {
		tvec3 temp(x + a, y + a, z + a);
		return temp;
	}
	inline tvec3 operator-( T a ) const { 
		tvec3 temp(x - a, y - a, z - a);
		return temp;
	}
	inline tvec3 operator*( T a ){ 
		tvec3 temp(x * a, y * a, z * a);
		return temp;
	}
	inline tvec3 operator/( T a ){ 
		tvec3 temp(x / a, y / a, z / a);
		return temp;
	}
		
	// length, normalize, dot product
	inline T length(){ 
		return sqrt((x*x) + (y*y) + (z*z));
	}
	inline tvec3 normalize(){ 
		tvec3 temp(x / length(), y / length(), z / length());
		return temp;
	}
	inline T dot( const tvec3& v ) const { 
		return (x*v.x + y*v.y + z*v.z);
	}

	// tvec3 only: cross product
	inline tvec3 operator^( tvec3& v ){ 
		tvec3 temp(y*v.z - z*v.y, -(x*v.z - z*v.x), x*v.y - y*v.x);
		return temp;
	}
	inline tvec3 operator^( const tvec3& v ) const { 
		tvec3 temp(y*v.z - z*v.y, -(x*v.z - z*v.x), x*v.y - y*v.x);
		return temp;
	}
	inline tvec3 cross( tvec3& v ){ 
		tvec3 temp(y*v.z - z*v.y, -(x*v.z - z*v.x), x*v.y - y*v.x);
		return temp;
	}
	inline tvec3 cross( const tvec3& v ) const { 
		tvec3 temp(y*v.z - z*v.y, -(x*v.z - z*v.x), x*v.y - y*v.x);
		return temp;
	}
};

template <class T> struct tvec4
{
	union { struct { T r, g, b, a; }; struct { T x, y, z, w; }; };

	// constructor/set
	tvec4(){ x=y=z=w=0; }
	tvec4( T a ){ x=y=z=w=a; }										inline void set( T a ){ x=y=z=w=a; }
	tvec4( T a, T b, T c, T d ){ x=a;y=b;z=c;w=d; }					inline void set( T a, T b, T c, T d ){ x=a;y=b;z=c;w=d; }
	tvec4( const tvec4& v ){ x=v.x;y=v.y;z=v.z;w=v.w; }				inline void set( const tvec4& v ){ x=v.x;y=v.y;z=v.z;w=v.w; }
	tvec4( const T* a ){ x=a[0];y=a[1];z=a[2];w=a[3]; }				inline void set( const T* a ){ x=a[0];y=a[1];z=a[2];w=a[3]; }
	tvec4( const tvec2<T>& v, T c, T d ){ x=v.x;y=v.y;z=c;w=d; }	inline void set( const tvec2<T>& v, T c, T d ){ x=v.x;y=v.y;z=c;w=d; }
	tvec4( T a, T b, const tvec2<T>& v ){ x=a;y=b;z=v.x;w=v.y; }	inline void set( T a, T b, const tvec2<T>& v ){ x=a;y=b;z=v.x;w=v.y; }	
	tvec4( const tvec3<T>& v, T d ){ x=v.x;y=v.y;z=v.z;w=d; }		inline void set( const tvec3<T>& v, T d ){ x=v.x;y=v.y;z=v.z;w=d; }
	tvec4( T a, const tvec3<T>& v ){ x=a;y=v.x;z=v.y;w=v.z; }		inline void set( T a, const tvec3<T>& v ){ x=a;y=v.x;z=v.y;w=v.z; }
	tvec4( const tvec2<T>& v1, const tvec2<T>& v2 ){ x=v1.x;y=v1.y;z=v2.x;w=v2.y; }
	inline void set( const tvec2<T>& v1, const tvec2<T>& v2 ){ x=v1.x;y=v1.y;z=v2.x;w=v2.y; }

	// assignment
	inline tvec4& operator=( T a ){ set(a); return *this; }
	inline tvec4& operator=( const T* a ){ set(a); return *this; }
	inline tvec4& operator+=( const tvec4& v ){ x+=v.x; y+=v.y; z+=v.z; w+=v.w; return *this; }
	inline tvec4& operator-=( const tvec4& v ){ x-=v.x; y-=v.y; z-=v.z; w-=v.w; return *this; }
	inline tvec4& operator*=( const tvec4& v ){ x*=v.x; y*=v.y; z*=v.z; w*=v.w; return *this; }
	inline tvec4& operator/=( const tvec4& v ){ x/=v.x; y/=v.y; z/=v.z; w/=v.w; return *this; }
	inline tvec4& operator+=( T a ){ x+=a; y+=a; z+=a; w+=a; return *this; }
	inline tvec4& operator-=( T a ){ x-=a; y-=a; z-=a; w-=a; return *this; }
	inline tvec4& operator*=( T a ){ x*=a; y*=a; z*=a; w*=a; return *this; }
	inline tvec4& operator/=( T a ){ x/=a; y/=a; z/=a; w/=a; return *this; }
	
	// casting
	inline operator T*(){ return &x; }
	inline operator const T*(){ return &x; }

	// array operator
	inline T& operator[](int i){
		if (i == 0)
			return x;
		if (i == 1)
			return y;
		if (i == 2)
			return z;
		if (i == 3)
			return w;
	}
	inline const T& operator[]( int i ) const { 
		if (i == 0)
			return x;
		if (i == 1)
			return y;
		if (i == 2)
			return z;
		if (i == 3)
			return w;
	}

	// unary operators
	inline tvec4 operator+(){ 
		tvec4 temp(x, y, z, w);
		return temp;
	}
	inline tvec4 operator+() const { 
		tvec4 temp(x, y, z, w);
		return temp;
	}
	inline tvec4 operator-(){
		tvec4 temp(-x, -y, -z, -w);
		return temp;
	}
	inline tvec4 operator-() const {
		tvec4 temp(-x, -y, -z, -w);
		return temp;
	}

	// binary operators
	inline tvec4 operator+(const tvec4& v) const {
		tvec4 temp(x+v.x, y+v.y, z+v.z, w+v.w);
		return temp;
	}
	inline tvec4 operator-(const tvec4& v) const {
		tvec4 temp(x - v.x, y - v.y, z - v.z, w - v.w);
		return temp;
	}
	inline tvec4 operator*(const tvec4& v) const {
		tvec4 temp(x * v.x, y * v.y, z * v.z, w * v.w);
		return temp;
	}
	inline tvec4 operator/(const tvec4& v) const {
		tvec4 temp(x / v.x, y / v.y, z / v.z, w / v.w);
		return temp;
	}
	inline tvec4 operator+(T a) const {
		tvec4 temp(x + a, y + a, z + a, w + a);
		return temp;
	}
	inline tvec4 operator-(T a) const {
		tvec4 temp(x - a, y - a, z - a, w - a);
		return temp;
	}
	inline tvec4 operator*(T a){
		tvec4 temp(x * a, y * a, z * a, w * a);
		return temp;
	}
	inline tvec4 operator/(T a){
		tvec4 temp(x / a, y / a, z / a, w / a);
		return temp;
	}

	// length, normalize, dot product
	inline T length(){ 
		return sqrt((x*x) + (y*y) + (z*z) + (w*w));
	}
	inline tvec4 normalize(){
		tvec4 temp(x / length(), y / length(), z / length(), w / length());
		return temp;
	}
	inline T dot( const tvec4& v ) const { 
		return(x*v.x + y*v.y + z*v.z + w*v.w);
	}
};

//*******************************************************************
// typedefs
typedef tvec2<float>	vec2;		typedef tvec3<float>	vec3;		typedef tvec4<float>	vec4;
typedef tvec2<int>		ivec2;		typedef tvec3<int>		ivec3;		typedef tvec4<int>		ivec4;

//*******************************************************************
// matrix 4x4: uses a standard row-major notation.
struct mat4
{
	union { float a[16]; struct {float _11,_12,_13,_14,_21,_22,_23,_24,_31,_32,_33,_34,_41,_42,_43,_44;}; };

	mat4(){ _12=_13=_14=_21=_23=_24=_31=_32=_34=_41=_42=_43=0.0f;_11=_22=_33=_44=1.0f; }
	mat4( float* f ){ memcpy(a,f,sizeof(float)*16); }
	mat4( float f11, float f12, float f13, float f14, float f21, float f22, float f23, float f24, float f31, float f32, float f33, float f34, float f41, float f42, float f43, float f44 ){_11=f11;_12=f12;_13=f13;_14=f14;_21=f21;_22=f22;_23=f23;_24=f24;_31=f31;_32=f32;_33=f33;_34=f34;_41=f41;_42=f42;_43=f43;_44=f44;}
	
	// casting
	inline operator float*(){ return a; }
	inline operator const float*() const { return a; }

	// array access operator
	inline float& operator[]( unsigned i ){ 
		return a[i];
	}
	inline float& operator[](int i){ 
		return a[i]; 
	}
	inline const float& operator[](unsigned i) const { 
		return a[i]; 
	}
	inline const float& operator[](int i) const { 
		return a[i]; 
	}
	
	// basic operation
	inline mat4& setIdentity(){ 
		_11 = 1;
		_12 = 0;
		_13 = 0;
		_14 = 0;
		_21 = 0;
		_22 = 1;
		_23 = 0;
		_24 = 0;
		_31 = 0;
		_32 = 0;
		_33 = 1;
		_34 = 0;
		_41 = 0;
		_42 = 0;
		_43 = 0;
		_44 = 1;
		return *this;
	}
	inline mat4 transpose() const {
		mat4 temp(_11, _21, _31, _41,
			_12, _22, _32, _42, 
			_13, _23, _33, _43, 
			_14, _24, _34, _44);
		return temp;
		
	}

	// binary operator overloading
	inline vec4 operator*( const vec4& v )
	{
		vec4 temp(_11 * v.x + _12 * v.y + _13 * v.z + _14 * v.w, 
			_21 * v.x + _22 * v.y + _23 * v.z + _24 * v.w,
			_31 * v.x + _32 * v.y + _33 * v.z + _34 * v.w,
			_41 * v.x + _42 * v.y + _43 * v.z + _44 * v.w);
		return temp;
	}
	inline mat4 operator*( mat4& M )
	{
		mat4 temp(_11 * M._11 + _12 * M._21 + _13 * M._31 + _14 * M._41,	//_11
			_11 * M._12 + _12 * M._22 + _13 * M._32 + _14 * M._42,			//_12
			_11 * M._13 + _12 * M._23 + _13 * M._33 + _14 * M._43,			//_13
			_11 * M._14 + _12 * M._24 + _13 * M._34 + _14 * M._44,			//_14
			_21 * M._11 + _22 * M._21 + _23 * M._31 + _24 * M._41,			//_21
			_21 * M._12 + _22 * M._22 + _23 * M._32 + _24 * M._42,			//_22
			_21 * M._13 + _22 * M._23 + _23 * M._33 + _24 * M._43,			//_23
			_21 * M._14 + _22 * M._24 + _23 * M._34 + _24 * M._44,			//_24
			_31 * M._11 + _32 * M._21 + _33 * M._31 + _34 * M._41,			//_31
			_31 * M._12 + _32 * M._22 + _33 * M._32 + _34 * M._42,			//_32
			_31 * M._13 + _32 * M._23 + _33 * M._33 + _34 * M._43,			//_33
			_31 * M._14 + _32 * M._24 + _33 * M._34 + _34 * M._44,			//_34
			_41 * M._11 + _42 * M._21 + _43 * M._31 + _44 * M._41,			//_41
			_41 * M._12 + _42 * M._22 + _43 * M._32 + _44 * M._42,			//_42
			_41 * M._13 + _42 * M._23 + _43 * M._33 + _44 * M._43,			//_43
			_41 * M._14 + _42 * M._24 + _43 * M._34 + _44 * M._44);			//_44
		return temp;
	}

	inline float determinant() const 
	{
		return _11 * _22 * _33 * _44 + _11 * _23 * _34 * _42 + _11 * _24 * _32 * _43
			+ _12 * _21 * _34 * _43 + _12 * _23 * _31 * _44 + _12 * _24 * _33 * _41
			+ _13 * _21 * _32 * _44 + _13 * _22 * _34 * _41 + _13 * _24 * _31 * _42
			+ _14 * _21 * _33 * _42 + _14 * _22 * _31 * _43 + _14 * _23 * _32 * _41
			- _11 * _22 * _34 * _43 - _11 * _23 * _32 * _44 - _11 * _24 * _33 * _42
			- _12 * _21 * _33 * _44 - _12 * _23 * _34 * _41 - _12 * _24 * _31 * _43
			- _13 * _21 * _34 * _42 - _13 * _22 * _31 * _44 - _13 * _24 * _32 * _41
			- _14 * _21 * _32 * _43 - _14 * _22 * _33 * _41 - _14 * _23 * _31 * _42;
	}

	inline mat4 inverse() const 
	{
		float det=determinant(); if( det==0 ) printf( "mat4::inverse() might be singular.\n" );
		mat4 temp(
			(_22 * _33 * _44 + _23 * _34 * _42 + _24 * _32 * _43 - _22 * _34 * _43 - _23 * _32 * _44 - _24 * _33 * _42) / det,	// _11
			(_12 * _34 * _43 + _13 * _32 * _44 + _14 * _33 * _42 - _12 * _33 * _44 - _13 * _34 * _42 - _14 * _32 * _43) / det,	// _12
			(_12 * _23 * _44 + _13 * _24 * _42 + _14 * _22 * _43 - _12 * _24 * _43 - _13 * _22 * _44 - _14 * _23 * _42) / det,	// _13
			(_12 * _24 * _33 + _13 * _22 * _34 + _14 * _23 * _32 - _12 * _23 * _34 - _13 * _24 * _32 - _14 * _22 * _33) / det,	// _14
			(_21 * _34 * _43 + _23 * _31 * _44 + _24 * _33 * _41 - _21 * _33 * _44 - _23 * _34 * _41 - _24 * _31 * _43) / det,	// _21
			(_11 * _33 * _44 + _13 * _34 * _41 + _14 * _31 * _43 - _11 * _34 * _43 - _13 * _31 * _44 - _14 * _33 * _41) / det,	// _22
			(_11 * _24 * _43 + _13 * _21 * _44 + _14 * _23 * _41 - _11 * _23 * _44 - _13 * _24 * _41 - _14 * _21 * _43) / det,	// _23
			(_11 * _23 * _34 + _13 * _24 * _31 + _14 * _21 * _33 - _11 * _24 * _33 - _13 * _21 * _34 - _14 * _23 * _31) / det,	// _24
			(_21 * _32 * _44 + _22 * _34 * _41 + _24 * _31 * _42 - _21 * _34 * _42 - _22 * _31 * _44 - _24 * _32 * _41) / det,	// _31
			(_11 * _34 * _42 + _12 * _31 * _44 + _14 * _32 * _41 - _11 * _32 * _44 - _12 * _34 * _41 - _14 * _31 * _42) / det,	// _32
			(_11 * _22 * _44 + _12 * _24 * _41 + _14 * _21 * _42 - _11 * _24 * _42 - _12 * _21 * _44 - _14 * _22 * _41) / det,	// _33
			(_11 * _24 * _32 + _12 * _21 * _34 + _14 * _22 * _31 - _11 * _22 * _34 - _12 * _24 * _31 - _14 * _21 * _32) / det,	// _34
			(_21 * _33 * _42 + _22 * _31 * _43 + _23 * _32 * _41 - _21 * _32 * _43 - _22 * _33 * _41 - _23 * _31 * _42) / det,	// _41
			(_11 * _32 * _43 + _12 * _33 * _41 + _13 * _31 * _42 - _11 * _33 * _42 - _12 * _31 * _43 - _13 * _32 * _41) / det,	// _42
			(_11 * _23 * _42 + _12 * _21 * _43 + _13 * _22 * _41 - _11 * _22 * _43 - _12 * _23 * _41 - _13 * _21 * _42) / det,	// _43
			(_11 * _22 * _33 + _12 * _23 * _31 + _13 * _21 * _32 - _11 * _23 * _32 - _12 * _21 * _33 - _13 * _22 * _31) / det);	// _44			
		return temp;
	}
};

//*******************************************************************
// additional utility functions
inline vec2 operator+( float f, vec2& v ){ return v+f; }
inline vec3 operator+( float f, vec3& v ){ return v+f; }
inline vec4 operator+( float f, vec4& v ){ return v+f; }
inline vec2 operator-( float f, vec2& v ){ return -v+f; }
inline vec3 operator-( float f, vec3& v ){ return -v+f; }
inline vec4 operator-( float f, vec4& v ){ return -v+f; }
inline vec2 operator*( float f, vec2& v ){ return v*f; }
inline vec3 operator*( float f, vec3& v ){ return v*f; }
inline vec4 operator*( float f, vec4& v ){ return v*f; }
inline float dot(vec2& v1,vec2& v2){ return v1.dot(v2); }
inline float dot(vec3& v1,vec3& v2){ return v1.dot(v2); }
inline float dot(vec4& v1,vec4& v2){ return v1.dot(v2); }

//*******************************************************************
// common macros
#ifndef _CRT_SECURE_NO_WARNINGS
	#define _CRT_SECURE_NO_WARNINGS
#endif
#ifndef PI
	#define PI 3.141592653589793f
#endif
#ifndef max
	#define max(a,b) ((a)>(b)?(a):(b))
#endif
#ifndef min
	#define min(a,b) ((a)<(b)?(a):(b))
#endif
#ifndef clamp
	#define clamp(value,vmin,vmax) (max(vmin,min(vmax,value)))
#endif
#ifndef isnan
	#define	isnan(x) (x!=x)
#endif
